#pragma once

typedef struct Simply Simply;
struct Simply;

Simply *simply_create();
void simply_destroy(Simply *simply);
